from django.apps import AppConfig


class PdfsConfig(AppConfig):
    name = 'pdfs'
